#include "Person.h"
#include "Utils.h"
#include <iostream>

Person::Person(const std::string& name, int age)
    : name(name), age(age), energy(80), happiness(70), monthsAlive(0) {}

int Person::clamp(int value, int lo, int hi) {
    if (value < lo) return lo;
    if (value > hi) return hi;
    return value;
}

std::string Person::getName() const { return name; }
int Person::getAge() const { return age; }
int Person::getEnergy() const { return energy; }
int Person::getHappiness() const { return happiness; }
int Person::getMonthsAlive() const { return monthsAlive; }

void Person::changeEnergy(int delta) {
    energy = clamp(energy + delta, 0, 100);
}

void Person::changeHappiness(int delta) {
    happiness = clamp(happiness + delta, 0, 100);
}

void Person::advanceMonth() {
    monthsAlive++;
    if (monthsAlive % 12 == 0) age++;

    // Passive monthly recovery -- a Sim isn't working every waking hour
    changeEnergy(+5);
}

void Person::restoreState(int energy_, int happiness_, int monthsAlive_) {
    energy = clamp(energy_, 0, 100);
    happiness = clamp(happiness_, 0, 100);
    monthsAlive = monthsAlive_ < 0 ? 0 : monthsAlive_;
}

bool Person::isBurnedOut() const {
    return energy < 25;
}

bool Person::isMiserable() const {
    return happiness < 25;
}

double Person::productivityMultiplier() const {
    if (isBurnedOut()) return 0.6;
    if (energy > 80) return 1.15;
    return 1.0;
}

void Person::printStatus() const {
    std::cout << Color::BOLD << name << Color::RESET
              << " | Age " << age
              << " | Energy: ";
    Utils::printBar(energy / 100.0, 10);
    std::cout << " " << energy << "%"
              << " | Happiness: ";
    Utils::printBar(happiness / 100.0, 10);
    std::cout << " " << happiness << "%\n";
}
