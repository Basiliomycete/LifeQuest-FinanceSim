#include <iostream>
#include <string>
#include "GameEngine.h"
#include "Utils.h"

// ---------------------------------------------------------------
// main.cpp
// Deliberately thin: its only job is to gather the one piece of
// information that must exist before GameEngine can be
// constructed (the Sim's name/age) and then hand control to
// GameEngine::run(). All simulation logic lives in the classes,
// not here.
// ---------------------------------------------------------------

int main() {
    std::cout << Color::BOLD << Color::MAGENTA
              << "=======================================\n"
              << "   LifeQuest: Finance Simulator\n"
              << "=======================================\n"
              << Color::RESET;

    std::cout << "What's your Sim's name? ";
    std::string name;
    std::getline(std::cin, name);
    if (name.empty()) name = "Alex";

    std::cout << "Starting age (default 22): ";
    std::string ageLine;
    std::getline(std::cin, ageLine);
    int age = 22;
    try {
        if (!ageLine.empty()) age = std::stoi(ageLine);
    } catch (...) {
        age = 22;
    }
    if (age < 16 || age > 90) age = 22;

    GameEngine engine(name, age);
    engine.run();

    return 0;
}
