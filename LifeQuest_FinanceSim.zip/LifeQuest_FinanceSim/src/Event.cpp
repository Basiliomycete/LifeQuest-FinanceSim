#include "Event.h"
#include "Utils.h"

LifeEvent::LifeEvent(const std::string& name) : name(name) {}
std::string LifeEvent::getName() const { return name; }

// --- BonusEvent ---

BonusEvent::BonusEvent() : LifeEvent("Work Bonus") {}
double BonusEvent::triggerChancePercent() const { return 8.0; }

std::string BonusEvent::apply(Person& person, Account& account) const {
    double amount = Utils::randomDouble(150, 900);
    account.deposit(amount);
    person.changeHappiness(+8);
    return person.getName() + " received a surprise bonus of " + Utils::money(amount) + "!";
}

// --- MedicalEmergencyEvent ---

MedicalEmergencyEvent::MedicalEmergencyEvent() : LifeEvent("Medical Emergency") {}
double MedicalEmergencyEvent::triggerChancePercent() const { return 5.0; }

std::string MedicalEmergencyEvent::apply(Person& person, Account& account) const {
    double amount = Utils::randomDouble(200, 1500);
    double charged = std::max(0.0, std::min(amount, account.getBalance()));
    account.withdraw(charged);
    person.changeHappiness(-15);
    person.changeEnergy(-20);
    return person.getName() + " had a medical emergency costing " + Utils::money(amount) + ".";
}

// --- LotteryWinEvent ---

LotteryWinEvent::LotteryWinEvent() : LifeEvent("Lottery Win") {}
double LotteryWinEvent::triggerChancePercent() const { return 1.0; }

std::string LotteryWinEvent::apply(Person& person, Account& account) const {
    double amount = Utils::randomDouble(1000, 5000);
    account.deposit(amount);
    person.changeHappiness(+25);
    return person.getName() + " won " + Utils::money(amount) + " in the lottery!!";
}

// --- TheftEvent ---

TheftEvent::TheftEvent() : LifeEvent("Theft") {}
double TheftEvent::triggerChancePercent() const { return 3.0; }

std::string TheftEvent::apply(Person& person, Account& account) const {
    double amount = std::max(0.0, std::min(account.getBalance(), Utils::randomDouble(50, 400)));
    account.withdraw(amount);
    person.changeHappiness(-10);
    return person.getName() + "'s belongings were stolen, losing " + Utils::money(amount) + ".";
}

// --- HolidayEvent ---

HolidayEvent::HolidayEvent() : LifeEvent("Holiday Trip") {}
double HolidayEvent::triggerChancePercent() const { return 6.0; }

std::string HolidayEvent::apply(Person& person, Account& account) const {
    double cost = Utils::randomDouble(100, 350);
    double affordable = std::max(0.0, std::min(cost, account.getBalance()));
    account.withdraw(affordable);
    person.changeHappiness(+15);
    person.changeEnergy(+10);
    return person.getName() + " took a short trip, spending " + Utils::money(affordable) + " but feeling refreshed.";
}

// --- HealthScareEvent ---

HealthScareEvent::HealthScareEvent() : LifeEvent("Health Scare") {}
double HealthScareEvent::triggerChancePercent() const { return 4.0; }

std::string HealthScareEvent::apply(Person& person, Account&) const {
    person.changeEnergy(-30);
    person.changeHappiness(-10);
    return person.getName() + " caught a bad flu and needs to rest.";
}
