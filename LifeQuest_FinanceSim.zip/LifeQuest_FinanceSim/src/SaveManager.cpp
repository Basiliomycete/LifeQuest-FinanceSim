#include "SaveManager.h"
#include <fstream>
#include <sstream>
#include <iostream>

// ---------------------------------------------------------------
// Implementation notes:
// We use dynamic_cast<ConcreteType*> to figure out, at save time,
// which concrete subclass a base-class pointer actually points to.
// This is RTTI-based polymorphism in action: the SaveManager never
// stores "what type am I" inside the objects themselves -- it asks
// the type system directly.
// ---------------------------------------------------------------

static void writeJob(std::ofstream& out, const Job* job) {
    if (!job) { out << "JOB|NONE\n"; return; }

    if (auto* j = dynamic_cast<const FullTimeJob*>(job)) {
        out << "JOB|FULLTIME|" << j->getTitle() << "|" << j->getBasePay()
            << "|" << j->getAnnualRaisePercent() << "\n";
    } else if (auto* j = dynamic_cast<const Freelancer*>(job)) {
        out << "JOB|FREELANCER|" << j->getTitle() << "|" << j->getBasePay()
            << "|" << j->getVolatility() << "\n";
    } else if (auto* j = dynamic_cast<const Entrepreneur*>(job)) {
        out << "JOB|ENTREPRENEUR|" << j->getTitle() << "|" << j->getBasePay()
            << "|" << j->getBusinessHealth() << "\n";
    } else if (auto* j = dynamic_cast<const PartTimeJob*>(job)) {
        out << "JOB|PARTTIME|" << j->getTitle() << "|" << j->getBasePay() << "\n";
    } else {
        out << "JOB|NONE\n";
    }
}

static void writeAccount(std::ofstream& out, const Account* acc) {
    if (auto* a = dynamic_cast<const SavingsAccount*>(acc)) {
        out << "ACCOUNT|SAVINGS|" << a->getName() << "|" << a->getBalance()
            << "|" << a->getAnnualInterestRate() << "\n";
    } else if (auto* a = dynamic_cast<const InvestmentAccount*>(acc)) {
        out << "ACCOUNT|INVESTMENT|" << a->getName() << "|" << a->getBalance()
            << "|" << a->getRiskLevel() << "\n";
    } else if (auto* a = dynamic_cast<const CheckingAccount*>(acc)) {
        out << "ACCOUNT|CHECKING|" << a->getName() << "|" << a->getBalance() << "\n";
    }
}

static void writeExpense(std::ofstream& out, const Expense* exp) {
    if (auto* e = dynamic_cast<const FixedBill*>(exp)) {
        out << "EXPENSE|FIXEDBILL|" << e->getLabel() << "|" << e->getMonthlyAmount() << "\n";
    } else if (auto* e = dynamic_cast<const VariableExpense*>(exp)) {
        out << "EXPENSE|VARIABLE|" << e->getLabel() << "|" << e->getMinAmount()
            << "|" << e->getMaxAmount() << "\n";
    } else if (auto* e = dynamic_cast<const EmergencyExpense*>(exp)) {
        out << "EXPENSE|EMERGENCY|" << e->getLabel() << "|" << e->getMonthlyAmount() << "\n";
    }
}

static void writeAsset(std::ofstream& out, const Asset* asset) {
    if (auto* a = dynamic_cast<const RealEstate*>(asset)) {
        out << "ASSET|REALESTATE|" << a->getName() << "|" << a->getPurchasePrice()
            << "|" << a->getCurrentValue() << "|" << a->getAppreciationRate() << "\n";
    } else if (auto* a = dynamic_cast<const Vehicle*>(asset)) {
        out << "ASSET|VEHICLE|" << a->getName() << "|" << a->getPurchasePrice()
            << "|" << a->getCurrentValue() << "|" << a->getDepreciationRate() << "\n";
    } else if (auto* a = dynamic_cast<const StockHolding*>(asset)) {
        out << "ASSET|STOCK|" << a->getName() << "|" << a->getPurchasePrice()
            << "|" << a->getCurrentValue() << "|" << a->getVolatility() << "\n";
    }
}

bool SaveManager::save(const std::string& filename,
                        const Person& person,
                        const Job* job,
                        const std::vector<std::unique_ptr<Account>>& accounts,
                        const std::vector<std::unique_ptr<Expense>>& expenses,
                        const std::vector<std::unique_ptr<Asset>>& assets,
                        int currentMonth) {
    std::ofstream out(filename);
    if (!out.is_open()) return false;

    out << "NAME|" << person.getName() << "\n";
    out << "AGE|" << person.getAge() << "\n";
    out << "ENERGY|" << person.getEnergy() << "\n";
    out << "HAPPINESS|" << person.getHappiness() << "\n";
    out << "MONTHS|" << person.getMonthsAlive() << "\n";
    out << "CURRENTMONTH|" << currentMonth << "\n";

    writeJob(out, job);

    out << "ACCOUNTS|" << accounts.size() << "\n";
    for (const auto& a : accounts) writeAccount(out, a.get());

    out << "EXPENSES|" << expenses.size() << "\n";
    for (const auto& e : expenses) writeExpense(out, e.get());

    out << "ASSETS|" << assets.size() << "\n";
    for (const auto& a : assets) writeAsset(out, a.get());

    return true;
}

// --- Small parsing helper: splits a line on '|' ---
static std::vector<std::string> splitPipe(const std::string& line) {
    std::vector<std::string> parts;
    std::stringstream ss(line);
    std::string token;
    while (std::getline(ss, token, '|')) parts.push_back(token);
    return parts;
}

bool SaveManager::load(const std::string& filename,
                        std::string& outName, int& outAge,
                        Person& person,
                        std::unique_ptr<Job>& job,
                        std::vector<std::unique_ptr<Account>>& accounts,
                        std::vector<std::unique_ptr<Expense>>& expenses,
                        std::vector<std::unique_ptr<Asset>>& assets,
                        int& currentMonth) {
    std::ifstream in(filename);
    if (!in.is_open()) return false;

    try {
        std::string line;
        int energy = 80, happiness = 70, months = 0;

        std::getline(in, line); outName = splitPipe(line)[1];
        std::getline(in, line); outAge = std::stoi(splitPipe(line)[1]);
        std::getline(in, line); energy = std::stoi(splitPipe(line)[1]);
        std::getline(in, line); happiness = std::stoi(splitPipe(line)[1]);
        std::getline(in, line); months = std::stoi(splitPipe(line)[1]);
        std::getline(in, line); currentMonth = std::stoi(splitPipe(line)[1]);

        person.restoreState(energy, happiness, months);

        std::getline(in, line);
        auto jobParts = splitPipe(line); // JOB|TAG|...
        const std::string& jobTag = jobParts[1];
        if (jobTag == "FULLTIME") {
            auto j = std::make_unique<FullTimeJob>(jobParts[2], std::stod(jobParts[3]), std::stod(jobParts[4]));
            job = std::move(j);
        } else if (jobTag == "FREELANCER") {
            job = std::make_unique<Freelancer>(jobParts[2], std::stod(jobParts[3]), std::stod(jobParts[4]));
        } else if (jobTag == "ENTREPRENEUR") {
            auto j = std::make_unique<Entrepreneur>(jobParts[2], std::stod(jobParts[3]));
            j->restoreBusinessHealth(std::stod(jobParts[4]));
            job = std::move(j);
        } else if (jobTag == "PARTTIME") {
            job = std::make_unique<PartTimeJob>(jobParts[2], std::stod(jobParts[3]));
        } else {
            job = nullptr;
        }

        accounts.clear();
        std::getline(in, line);
        int accountCount = std::stoi(splitPipe(line)[1]);
        for (int i = 0; i < accountCount; ++i) {
            std::getline(in, line);
            auto p = splitPipe(line); // ACCOUNT|TAG|name|balance|extra
            const std::string& tag = p[1];
            double balance = std::stod(p[3]);
            if (tag == "SAVINGS") {
                auto a = std::make_unique<SavingsAccount>(p[2], 0.0, std::stod(p[4]));
                a->restoreBalance(balance);
                accounts.push_back(std::move(a));
            } else if (tag == "INVESTMENT") {
                auto a = std::make_unique<InvestmentAccount>(p[2], 0.0, std::stod(p[4]));
                a->restoreBalance(balance);
                accounts.push_back(std::move(a));
            } else if (tag == "CHECKING") {
                auto a = std::make_unique<CheckingAccount>(p[2], 0.0);
                a->restoreBalance(balance);
                accounts.push_back(std::move(a));
            }
        }

        expenses.clear();
        std::getline(in, line);
        int expenseCount = std::stoi(splitPipe(line)[1]);
        for (int i = 0; i < expenseCount; ++i) {
            std::getline(in, line);
            auto p = splitPipe(line); // EXPENSE|TAG|label|...
            const std::string& tag = p[1];
            if (tag == "FIXEDBILL") {
                expenses.push_back(std::make_unique<FixedBill>(p[2], std::stod(p[3])));
            } else if (tag == "VARIABLE") {
                expenses.push_back(std::make_unique<VariableExpense>(p[2], std::stod(p[3]), std::stod(p[4])));
            } else if (tag == "EMERGENCY") {
                expenses.push_back(std::make_unique<EmergencyExpense>(p[2], std::stod(p[3])));
            }
        }

        assets.clear();
        std::getline(in, line);
        int assetCount = std::stoi(splitPipe(line)[1]);
        for (int i = 0; i < assetCount; ++i) {
            std::getline(in, line);
            auto p = splitPipe(line); // ASSET|TAG|name|purchasePrice|currentValue|extra
            const std::string& tag = p[1];
            double purchasePrice = std::stod(p[3]);
            double currentValue = std::stod(p[4]);
            if (tag == "REALESTATE") {
                auto a = std::make_unique<RealEstate>(p[2], purchasePrice, std::stod(p[5]));
                a->restoreValue(currentValue);
                assets.push_back(std::move(a));
            } else if (tag == "VEHICLE") {
                auto a = std::make_unique<Vehicle>(p[2], purchasePrice, std::stod(p[5]));
                a->restoreValue(currentValue);
                assets.push_back(std::move(a));
            } else if (tag == "STOCK") {
                auto a = std::make_unique<StockHolding>(p[2], purchasePrice, std::stod(p[5]));
                a->restoreValue(currentValue);
                assets.push_back(std::move(a));
            }
        }

        return true;
    } catch (...) {
        // Any malformed line (bad index, bad stoi, etc.) -> treat as corrupt save
        return false;
    }
}
