#include "Job.h"
#include "Utils.h"

// --- Job (base) ---

Job::Job(const std::string& title, double baseMonthlyPay)
    : title(title), baseMonthlyPay(baseMonthlyPay) {}

std::string Job::getTitle() const { return title; }
double Job::getBasePay() const { return baseMonthlyPay; }

int Job::energyCost() const { return 15; }

std::string Job::describe() const {
    return title + " (" + Utils::money(baseMonthlyPay) + "/mo base)";
}

// --- PartTimeJob ---

PartTimeJob::PartTimeJob(const std::string& title, double basePay)
    : Job(title, basePay) {}

double PartTimeJob::calculateMonthlyIncome(const Person& person) const {
    return baseMonthlyPay * person.productivityMultiplier();
}

int PartTimeJob::energyCost() const { return 8; }

// --- FullTimeJob ---

FullTimeJob::FullTimeJob(const std::string& title, double basePay, double annualRaisePercent)
    : Job(title, basePay), annualRaisePercent(annualRaisePercent) {}

double FullTimeJob::calculateMonthlyIncome(const Person& person) const {
    int yearsWorked = person.getMonthsAlive() / 12;
    double raiseMultiplier = 1.0;
    for (int i = 0; i < yearsWorked; ++i) raiseMultiplier *= (1.0 + annualRaisePercent / 100.0);
    return baseMonthlyPay * raiseMultiplier * person.productivityMultiplier();
}

int FullTimeJob::energyCost() const { return 20; }

double FullTimeJob::getAnnualRaisePercent() const { return annualRaisePercent; }

// --- Freelancer ---

Freelancer::Freelancer(const std::string& title, double basePay, double volatility)
    : Job(title, basePay), volatility(volatility) {}

double Freelancer::calculateMonthlyIncome(const Person& person) const {
    double swing = Utils::randomDouble(-volatility, volatility);
    double income = baseMonthlyPay * (1.0 + swing) * person.productivityMultiplier();
    return income < 0 ? 0 : income;
}

int Freelancer::energyCost() const { return 12; }

std::string Freelancer::describe() const {
    return Job::describe() + " [freelance, income varies]";
}

double Freelancer::getVolatility() const { return volatility; }

// --- Entrepreneur ---

Entrepreneur::Entrepreneur(const std::string& title, double basePay)
    : Job(title, basePay), businessHealth(1.0) {}

double Entrepreneur::calculateMonthlyIncome(const Person& person) const {
    double income = baseMonthlyPay * businessHealth * person.productivityMultiplier();
    return income;
}

int Entrepreneur::energyCost() const { return 25; }

std::string Entrepreneur::describe() const {
    return Job::describe() + " [business health: " + std::to_string(static_cast<int>(businessHealth * 100)) + "%]";
}

void Entrepreneur::evolveBusiness() {
    double change = Utils::randomDouble(-0.15, 0.20); // slightly biased toward growth
    businessHealth += change;
    if (businessHealth < 0.1) businessHealth = 0.1;
    if (businessHealth > 2.5) businessHealth = 2.5;
}

double Entrepreneur::getBusinessHealth() const { return businessHealth; }

void Entrepreneur::restoreBusinessHealth(double health) { businessHealth = health; }
