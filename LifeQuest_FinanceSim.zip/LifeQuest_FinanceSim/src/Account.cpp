#include "Account.h"
#include "Utils.h"
#include <iostream>

// --- Account (base) ---

Account::Account(const std::string& accountName, double openingBalance)
    : accountName(accountName), balance(openingBalance) {}

std::string Account::getName() const { return accountName; }
double Account::getBalance() const { return balance; }

bool Account::deposit(double amount) {
    if (amount < 0) return false;
    balance += amount;
    return true;
}

bool Account::withdraw(double amount) {
    if (amount < 0 || amount > balance) return false;
    balance -= amount;
    return true;
}

void Account::restoreBalance(double exactBalance) {
    balance = exactBalance;
}

void Account::printSummary() const {
    std::cout << "  " << Color::CYAN << typeName() << Color::RESET
              << " \"" << accountName << "\": " << Utils::money(balance) << "\n";
}

// --- CheckingAccount ---

CheckingAccount::CheckingAccount(const std::string& name, double openingBalance)
    : Account(name, openingBalance) {}

void CheckingAccount::applyMonthlyEffect() {
    const double MIN_BALANCE_NO_FEE = 100.0;
    const double LOW_BALANCE_FEE = 5.0;
    // Note: deliberately does NOT clamp a negative result back to 0.
    // A negative balance represents real debt from unpaid bills, and
    // GameEngine's missed-payment tracking depends on that debt being
    // visible rather than silently forgiven by a fee calculation.
    if (balance < MIN_BALANCE_NO_FEE) {
        balance -= LOW_BALANCE_FEE;
    }
}

std::string CheckingAccount::typeName() const { return "Checking"; }

// --- SavingsAccount ---

SavingsAccount::SavingsAccount(const std::string& name, double openingBalance, double annualInterestRate)
    : Account(name, openingBalance), annualInterestRate(annualInterestRate) {}

void SavingsAccount::applyMonthlyEffect() {
    double monthlyRate = annualInterestRate / 12.0;
    balance += balance * monthlyRate;
}

std::string SavingsAccount::typeName() const { return "Savings"; }

double SavingsAccount::getAnnualInterestRate() const { return annualInterestRate; }

// --- InvestmentAccount ---

InvestmentAccount::InvestmentAccount(const std::string& name, double openingBalance, double riskLevel)
    : Account(name, openingBalance), riskLevel(riskLevel) {}

void InvestmentAccount::applyMonthlyEffect() {
    // Higher risk -> wider swing range, slightly positive expected value
    double swingRange = 0.03 + riskLevel * 0.12; // 3% to 15% monthly swing
    double drift = 0.004 + riskLevel * 0.006;    // small expected upward drift
    double change = Utils::randomDouble(-swingRange, swingRange) + drift;
    balance += balance * change;
    if (balance < 0) balance = 0;
}

std::string InvestmentAccount::typeName() const { return "Investment"; }
double InvestmentAccount::getRiskLevel() const { return riskLevel; }
