#include "GameEngine.h"
#include "SaveManager.h"
#include "Utils.h"
#include <iostream>
#include <limits>
#include <algorithm>

// ---------------------------------------------------------------
// GameEngine.cpp
// ---------------------------------------------------------------

GameEngine::GameEngine(const std::string& playerName, int startingAge)
    : person(playerName, startingAge),
      currentJob(nullptr),
      currentMonth(1),
      gameOver(false),
      missedPaymentStreak(0) {
    buildStartingState();
    buildEventPool();
}

void GameEngine::buildStartingState() {
    currentJob = std::make_unique<PartTimeJob>("Barista", 900.0);

    accounts.push_back(std::make_unique<CheckingAccount>("Main Checking", 500.0));
    accounts.push_back(std::make_unique<SavingsAccount>("Rainy Day Fund", 200.0, 0.04));

    expenses.push_back(std::make_unique<FixedBill>("Rent", 650.0));
    expenses.push_back(std::make_unique<FixedBill>("Utilities", 90.0));
    expenses.push_back(std::make_unique<VariableExpense>("Groceries & Food", 150.0, 320.0));
    expenses.push_back(std::make_unique<VariableExpense>("Entertainment", 30.0, 120.0));
}

void GameEngine::buildEventPool() {
    eventPool.push_back(std::make_unique<BonusEvent>());
    eventPool.push_back(std::make_unique<MedicalEmergencyEvent>());
    eventPool.push_back(std::make_unique<LotteryWinEvent>());
    eventPool.push_back(std::make_unique<TheftEvent>());
    eventPool.push_back(std::make_unique<HolidayEvent>());
    eventPool.push_back(std::make_unique<HealthScareEvent>());
}

// --- Aggregation helpers (polymorphic sums over the owned collections) ---

double GameEngine::totalLiquidCash() const {
    double sum = 0;
    for (const auto& a : accounts) sum += a->getBalance();
    return sum;
}

double GameEngine::totalAssetValue() const {
    double sum = 0;
    for (const auto& a : assets) sum += a->getCurrentValue();
    return sum;
}

double GameEngine::netWorth() const {
    return totalLiquidCash() + totalAssetValue();
}

double GameEngine::totalMonthlyExpenses() const {
    double sum = 0;
    for (const auto& e : expenses) sum += e->getMonthlyAmount();
    return sum;
}

// --- Display ---

void GameEngine::printDashboard() const {
    std::cout << "\n" << Color::BOLD << Color::MAGENTA
              << "================= Month " << currentMonth << " ================="
              << Color::RESET << "\n";
    person.printStatus();
    std::cout << "Job: " << Color::YELLOW << currentJob->describe() << Color::RESET << "\n";
    std::cout << "Accounts:\n";
    for (const auto& a : accounts) a->printSummary();
    if (!assets.empty()) {
        std::cout << "Assets:\n";
        for (const auto& a : assets) std::cout << "  " << a->describe() << "\n";
    }
    std::cout << Color::BOLD << "Net worth: " << Color::GREEN << Utils::money(netWorth())
              << Color::RESET << "\n";
}

void GameEngine::printMainMenu() const {
    std::cout << "\n" << Color::CYAN << "What would you like to do?" << Color::RESET << "\n"
              << "  1. Advance to next month\n"
              << "  2. Deposit into an account\n"
              << "  3. Withdraw from an account\n"
              << "  4. Open a new account\n"
              << "  5. Buy an asset\n"
              << "  6. Sell an asset\n"
              << "  7. Switch job\n"
              << "  8. View net worth breakdown\n"
              << "  9. Save game\n"
              << " 10. Load game\n"
              << "  0. Quit\n"
              << "Choice: ";
}

// --- Helpers for console input ---

static int readInt() {
    int value;
    while (!(std::cin >> value)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Please enter a number: ";
    }
    return value;
}

static double readDouble() {
    double value;
    while (!(std::cin >> value)) {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Please enter a number: ";
    }
    return value;
}

static std::string readLine() {
    std::string line;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::getline(std::cin, line);
    return line;
}

Account* GameEngine::chooseAccount(const std::string& prompt) {
    std::cout << prompt << "\n";
    for (size_t i = 0; i < accounts.size(); ++i) {
        std::cout << "  " << (i + 1) << ". " << accounts[i]->getName()
                   << " (" << accounts[i]->typeName() << ", " << Utils::money(accounts[i]->getBalance()) << ")\n";
    }
    std::cout << "Choice: ";
    int choice = readInt();
    if (choice < 1 || choice > static_cast<int>(accounts.size())) return nullptr;
    return accounts[choice - 1].get();
}

// --- Menu actions ---

void GameEngine::doDeposit() {
    Account* acc = chooseAccount("Deposit into which account?");
    if (!acc) { std::cout << "Invalid choice.\n"; return; }
    std::cout << "Amount to deposit: ";
    double amount = readDouble();
    if (acc->deposit(amount)) std::cout << Color::GREEN << "Deposited " << Utils::money(amount) << ".\n" << Color::RESET;
    else std::cout << Color::RED << "Invalid amount.\n" << Color::RESET;
}

void GameEngine::doWithdraw() {
    Account* acc = chooseAccount("Withdraw from which account?");
    if (!acc) { std::cout << "Invalid choice.\n"; return; }
    std::cout << "Amount to withdraw: ";
    double amount = readDouble();
    if (acc->withdraw(amount)) std::cout << Color::GREEN << "Withdrew " << Utils::money(amount) << ".\n" << Color::RESET;
    else std::cout << Color::RED << "Insufficient funds or invalid amount.\n" << Color::RESET;
}

void GameEngine::doOpenAccount() {
    std::cout << "Account type:\n  1. Checking\n  2. Savings\n  3. Investment\nChoice: ";
    int type = readInt();
    std::cout << "Account name: ";
    std::string name = readLine();
    std::cout << "Opening deposit: ";
    double opening = readDouble();

    if (type == 1) accounts.push_back(std::make_unique<CheckingAccount>(name, opening));
    else if (type == 2) accounts.push_back(std::make_unique<SavingsAccount>(name, opening));
    else if (type == 3) accounts.push_back(std::make_unique<InvestmentAccount>(name, opening));
    else { std::cout << "Invalid type.\n"; return; }

    std::cout << Color::GREEN << "Account opened.\n" << Color::RESET;
}

void GameEngine::doBuyAsset() {
    Account* acc = chooseAccount("Pay from which account?");
    if (!acc) { std::cout << "Invalid choice.\n"; return; }

    std::cout << "Asset type:\n  1. Real Estate\n  2. Vehicle\n  3. Stock\nChoice: ";
    int type = readInt();
    std::cout << "Asset name: ";
    std::string name = readLine();
    std::cout << "Price: ";
    double price = readDouble();

    if (!acc->withdraw(price)) {
        std::cout << Color::RED << "Insufficient funds in that account.\n" << Color::RESET;
        return;
    }

    if (type == 1) assets.push_back(std::make_unique<RealEstate>(name, price));
    else if (type == 2) assets.push_back(std::make_unique<Vehicle>(name, price));
    else if (type == 3) assets.push_back(std::make_unique<StockHolding>(name, price));
    else { acc->deposit(price); std::cout << "Invalid type, refunded.\n"; return; }

    std::cout << Color::GREEN << "Purchased " << name << " for " << Utils::money(price) << ".\n" << Color::RESET;
}

void GameEngine::doSellAsset() {
    if (assets.empty()) { std::cout << "You don't own any assets.\n"; return; }
    std::cout << "Sell which asset?\n";
    for (size_t i = 0; i < assets.size(); ++i)
        std::cout << "  " << (i + 1) << ". " << assets[i]->describe() << "\n";
    std::cout << "Choice: ";
    int choice = readInt();
    if (choice < 1 || choice > static_cast<int>(assets.size())) { std::cout << "Invalid choice.\n"; return; }

    Account* acc = chooseAccount("Deposit proceeds into which account?");
    if (!acc) { std::cout << "Invalid choice.\n"; return; }

    double value = assets[choice - 1]->getCurrentValue();
    acc->deposit(value);
    std::cout << Color::GREEN << "Sold " << assets[choice - 1]->getName()
              << " for " << Utils::money(value) << ".\n" << Color::RESET;
    assets.erase(assets.begin() + (choice - 1));
}

void GameEngine::doSwitchJob() {
    std::cout << "Choose a new job:\n"
              << "  1. Part-time: Retail Associate ($1100/mo)\n"
              << "  2. Full-time: Software Engineer ($3800/mo, 4% annual raise)\n"
              << "  3. Full-time: Nurse ($3200/mo, 5% annual raise)\n"
              << "  4. Freelancer: Graphic Designer ($2000/mo, volatile)\n"
              << "  5. Entrepreneur: Indie Game Studio ($1500/mo base, business can grow or shrink)\n"
              << "Choice: ";
    int choice = readInt();
    switch (choice) {
        case 1: currentJob = std::make_unique<PartTimeJob>("Retail Associate", 1100.0); break;
        case 2: currentJob = std::make_unique<FullTimeJob>("Software Engineer", 3800.0, 4.0); break;
        case 3: currentJob = std::make_unique<FullTimeJob>("Nurse", 3200.0, 5.0); break;
        case 4: currentJob = std::make_unique<Freelancer>("Graphic Designer", 2000.0, 0.45); break;
        case 5: currentJob = std::make_unique<Entrepreneur>("Indie Game Studio", 1500.0); break;
        default: std::cout << "Invalid choice, job unchanged.\n"; return;
    }
    std::cout << Color::GREEN << "New job: " << currentJob->describe() << Color::RESET << "\n";
}

void GameEngine::doViewNetWorth() {
    std::cout << "\n" << Color::BOLD << "--- Net Worth Breakdown ---" << Color::RESET << "\n";
    std::cout << "Liquid cash:\n";
    for (const auto& a : accounts) a->printSummary();
    std::cout << "  Subtotal: " << Utils::money(totalLiquidCash()) << "\n";

    std::cout << "Assets:\n";
    if (assets.empty()) std::cout << "  (none)\n";
    for (const auto& a : assets) std::cout << "  " << a->describe() << "\n";
    std::cout << "  Subtotal: " << Utils::money(totalAssetValue()) << "\n";

    std::cout << Color::BOLD << Color::GREEN << "Total net worth: " << Utils::money(netWorth())
              << Color::RESET << "\n";
}

void GameEngine::doSaveGame() {
    std::cout << "Save file name (e.g. mysave.txt): ";
    std::string filename = readLine();
    bool ok = SaveManager::save(filename, person, currentJob.get(), accounts, expenses, assets, currentMonth);
    std::cout << (ok ? Color::GREEN : Color::RED)
               << (ok ? "Game saved.\n" : "Could not save game.\n") << Color::RESET;
}

void GameEngine::doLoadGame() {
    std::cout << "Save file name to load: ";
    std::string filename = readLine();

    std::string loadedName; int loadedAge = 0;
    bool ok = SaveManager::load(filename, loadedName, loadedAge, person, currentJob,
                                 accounts, expenses, assets, currentMonth);
    if (!ok) {
        std::cout << Color::RED << "Could not load that save file.\n" << Color::RESET;
        return;
    }
    // Rebuild Person with the saved name/age, then re-run load() once more
    // so its restoreState() call lands on the freshly-rebuilt object.
    person = Person(loadedName, loadedAge);
    SaveManager::load(filename, loadedName, loadedAge, person, currentJob,
                       accounts, expenses, assets, currentMonth);
    std::cout << Color::GREEN << "Game loaded.\n" << Color::RESET;
}

// --- Core monthly simulation step ---

void GameEngine::doAdvanceMonth() {
    std::cout << "\n" << Color::BOLD << "--- Advancing to month " << (currentMonth + 1)
               << " ---" << Color::RESET << "\n";

    // 1. Income
    double income = currentJob->calculateMonthlyIncome(person);
    if (!accounts.empty()) accounts.front()->deposit(income);
    person.changeEnergy(-currentJob->energyCost());
    std::cout << "Earned " << Utils::money(income) << " from " << currentJob->getTitle() << ".\n";

    if (auto* ent = dynamic_cast<Entrepreneur*>(currentJob.get())) ent->evolveBusiness();

    // 2. Expenses (paid from the first account; allow going into debt rather than crash)
    double totalExpense = 0;
    for (auto& e : expenses) totalExpense += e->getMonthlyAmount();

    if (!accounts.empty()) {
        Account* payer = accounts.front().get();
        if (payer->withdraw(totalExpense)) {
            missedPaymentStreak = 0;
        } else {
            // Not enough funds -- force the account into debt and penalize happiness.
            double shortfall = totalExpense - payer->getBalance();
            payer->restoreBalance(payer->getBalance() - totalExpense); // can go negative
            missedPaymentStreak++;
            person.changeHappiness(-20);
            std::cout << Color::RED << "Couldn't fully cover " << Utils::money(totalExpense)
                       << " in bills! Short by " << Utils::money(shortfall) << ".\n" << Color::RESET;
        }
    }
    std::cout << "Paid " << Utils::money(totalExpense) << " in expenses.\n";

    // Remove one-time expenses that already fired
    expenses.erase(std::remove_if(expenses.begin(), expenses.end(),
                        [](const std::unique_ptr<Expense>& e) { return !e->isRecurring(); }),
                    expenses.end());

    // 3. Accounts apply their own monthly effect (interest / market swings / fees)
    for (auto& a : accounts) a->applyMonthlyEffect();

    // 4. Assets appreciate/depreciate
    for (auto& a : assets) a->updateValueMonthly();

    // 5. Random life events
    if (!accounts.empty()) {
        for (auto& ev : eventPool) {
            if (Utils::chance(ev->triggerChancePercent())) {
                std::string msg = ev->apply(person, *accounts.front());
                std::cout << Color::YELLOW << "[Event] " << msg << Color::RESET << "\n";
            }
        }
    }

    person.advanceMonth();
    currentMonth++;

    checkGameOverConditions();
}

void GameEngine::checkGameOverConditions() {
    if (missedPaymentStreak >= 3) {
        std::cout << Color::RED << Color::BOLD
                   << "\nYou've missed bill payments for 3 months in a row. Bankruptcy! Game over.\n"
                   << Color::RESET;
        gameOver = true;
    }
    if (person.getHappiness() <= 0) {
        std::cout << Color::RED << Color::BOLD
                   << "\n" << person.getName() << " has burned out completely. Game over.\n"
                   << Color::RESET;
        gameOver = true;
    }
}

// --- Main loop ---

void GameEngine::run() {
    std::cout << Color::BOLD << Color::CYAN
               << "\nWelcome to LifeQuest: Finance Simulator, " << person.getName() << "!\n"
               << Color::RESET
               << "Survive, grow your net worth, and try not to go broke.\n";

    while (!gameOver) {
        printDashboard();
        printMainMenu();
        int choice = readInt();

        switch (choice) {
            case 1: doAdvanceMonth(); break;
            case 2: doDeposit(); break;
            case 3: doWithdraw(); break;
            case 4: doOpenAccount(); break;
            case 5: doBuyAsset(); break;
            case 6: doSellAsset(); break;
            case 7: doSwitchJob(); break;
            case 8: doViewNetWorth(); break;
            case 9: doSaveGame(); break;
            case 10: doLoadGame(); break;
            case 0:
                std::cout << "Thanks for playing! Final net worth: " << Utils::money(netWorth()) << "\n";
                return;
            default:
                std::cout << "Invalid choice.\n";
        }
    }

    std::cout << "Final net worth: " << Utils::money(netWorth())
               << " after " << currentMonth << " months.\n";
}
