#include "Expense.h"
#include "Utils.h"

Expense::Expense(const std::string& label) : label(label) {}
std::string Expense::getLabel() const { return label; }

std::string Expense::describe() const {
    return label + ": " + Utils::money(getMonthlyAmount()) + (isRecurring() ? "/mo" : " (one-time)");
}

// --- FixedBill ---

FixedBill::FixedBill(const std::string& label, double amount) : Expense(label), amount(amount) {}
double FixedBill::getMonthlyAmount() const { return amount; }
bool FixedBill::isRecurring() const { return true; }

// --- VariableExpense ---

VariableExpense::VariableExpense(const std::string& label, double minAmount, double maxAmount)
    : Expense(label), minAmount(minAmount), maxAmount(maxAmount) {}

double VariableExpense::getMonthlyAmount() const {
    return Utils::randomDouble(minAmount, maxAmount);
}

bool VariableExpense::isRecurring() const { return true; }

double VariableExpense::getMinAmount() const { return minAmount; }
double VariableExpense::getMaxAmount() const { return maxAmount; }

// --- EmergencyExpense ---

EmergencyExpense::EmergencyExpense(const std::string& label, double amount)
    : Expense(label), amount(amount) {}

double EmergencyExpense::getMonthlyAmount() const { return amount; }
bool EmergencyExpense::isRecurring() const { return false; }
