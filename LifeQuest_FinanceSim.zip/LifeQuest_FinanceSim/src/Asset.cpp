#include "Asset.h"
#include "Utils.h"

Asset::Asset(const std::string& name, double purchasePrice)
    : name(name), purchasePrice(purchasePrice), currentValue(purchasePrice) {}

std::string Asset::getName() const { return name; }
double Asset::getPurchasePrice() const { return purchasePrice; }
double Asset::getCurrentValue() const { return currentValue; }

std::string Asset::describe() const {
    return typeName() + " \"" + name + "\": " + Utils::money(currentValue) +
           " (bought at " + Utils::money(purchasePrice) + ")";
}

void Asset::restoreValue(double exactValue) {
    currentValue = exactValue;
}

// --- RealEstate ---

RealEstate::RealEstate(const std::string& name, double purchasePrice, double annualAppreciationRate)
    : Asset(name, purchasePrice), annualAppreciationRate(annualAppreciationRate) {}

void RealEstate::updateValueMonthly() {
    double monthlyRate = annualAppreciationRate / 12.0;
    currentValue += currentValue * monthlyRate;
}

std::string RealEstate::typeName() const { return "Real Estate"; }

double RealEstate::getAppreciationRate() const { return annualAppreciationRate; }

// --- Vehicle ---

Vehicle::Vehicle(const std::string& name, double purchasePrice, double annualDepreciationRate)
    : Asset(name, purchasePrice), annualDepreciationRate(annualDepreciationRate) {}

void Vehicle::updateValueMonthly() {
    double monthlyRate = annualDepreciationRate / 12.0;
    currentValue -= currentValue * monthlyRate;
    if (currentValue < 0) currentValue = 0;
}

std::string Vehicle::typeName() const { return "Vehicle"; }

double Vehicle::getDepreciationRate() const { return annualDepreciationRate; }

// --- StockHolding ---

StockHolding::StockHolding(const std::string& name, double purchasePrice, double volatility)
    : Asset(name, purchasePrice), volatility(volatility) {}

void StockHolding::updateValueMonthly() {
    double change = Utils::randomDouble(-volatility, volatility);
    currentValue += currentValue * change;
    if (currentValue < 0) currentValue = 0;
}

std::string StockHolding::typeName() const { return "Stock"; }

double StockHolding::getVolatility() const { return volatility; }
