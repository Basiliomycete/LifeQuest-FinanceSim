# LifeQuest: Finance Simulator

**Course:** Advanced Programming
**Instructor:** Dr. Samaneh Pahlavani
**Student:** Reyhaneh Fakouri

A console-based, Sims-style personal finance management game written in C++17,
built around a full OOP class hierarchy.

## How to build

### Linux / macOS
```
make          # builds ./lifequest
make run      # builds and runs it
make clean    # removes build artifacts
```
Requires a C++17 compiler (tested with g++ 13). No external dependencies.

### Windows

**Option A — MSYS2 (command line, recommended):**
1. Install MSYS2 from [msys2.org](https://www.msys2.org/)
2. In the MSYS2 (UCRT64) terminal: `pacman -S mingw-w64-ucrt-x86_64-gcc make`
3. Copy the project folder somewhere accessible, e.g. `C:\LifeQuest_FinanceSim`
4. ```
   cd /c/LifeQuest_FinanceSim
   make
   ./lifequest.exe
   ```

**Option B — Code::Blocks / Dev-C++ (GUI, no command line):**
1. Install either IDE (both bundle MinGW)
2. Create a new empty Console Application project
3. Add every file from `src/*.cpp` to the project
4. Add `include/` to the project's Include Search Path
5. Build & Run

> Note: ANSI color codes may print as raw escape sequences on old `cmd.exe`.
> Run from **Windows Terminal** or a modern PowerShell window instead.

### Android (Termux)
1. Install [Termux](https://f-droid.org/packages/com.termux/) from F-Droid (the Play Store build is outdated)
2. ```
   pkg update && pkg install clang make zip unzip
   termux-setup-storage      # answer 'y' when prompted, then press Enter
   ```
3. Copy the project zip into Termux's storage and unpack it, e.g.:
   ```
   cp /sdcard/Download/LifeQuest_FinanceSim.zip .
   unzip LifeQuest_FinanceSim.zip
   cd LifeQuest_FinanceSim
   ```
4. ```
   make CXX=clang++
   ./lifequest
   ```
   (Termux ships `clang` by default, not `g++`, so the compiler is overridden explicitly.)

The Makefile auto-detects Windows and names the binary `lifequest.exe`; on
Linux/macOS/Android it stays `lifequest`.

## Gameplay

You play one Sim through their financial life, one month at a time. Each
turn you can: advance the month, move money between accounts, buy/sell
assets, switch jobs, save/load your game, and check your net worth. Random
life events (bonuses, medical emergencies, theft, lottery wins, ...) can hit
you each month. Run your bills 3 months in a row without enough cash and
it's bankruptcy; let happiness hit zero and you burn out. Otherwise, keep
playing and try to grow your net worth.

## Project structure

```
include/        Header files (class declarations)
src/            Implementation files (.cpp) + main.cpp
Makefile
```

| File           | Class(es)                                            |
|----------------|-------------------------------------------------------|
| Person         | `Person`                                              |
| Job            | `Job` (abstract), `PartTimeJob`, `FullTimeJob`, `Freelancer`, `Entrepreneur` |
| Account        | `Account` (abstract), `CheckingAccount`, `SavingsAccount`, `InvestmentAccount` |
| Expense        | `Expense` (abstract), `FixedBill`, `VariableExpense`, `EmergencyExpense` |
| Asset          | `Asset` (abstract), `RealEstate`, `Vehicle`, `StockHolding` |
| Event          | `LifeEvent` (abstract), `BonusEvent`, `MedicalEmergencyEvent`, `LotteryWinEvent`, `TheftEvent`, `HolidayEvent`, `HealthScareEvent` |
| GameEngine     | `GameEngine` -- owns everything, runs the console menu loop |
| SaveManager    | `SaveManager` -- save/load to a plain text file        |
| Utils          | free helper functions (colors, currency formatting, RNG) |

## How each OOP pillar shows up

**Encapsulation** -- `Person`'s `energy`/`happiness`/`age` are private and
can only change through methods that enforce valid ranges (e.g.
`changeHappiness` clamps to 0-100). `Account` only exposes `deposit()` /
`withdraw()`; nothing outside the class can set `balance` directly except
through the explicitly-named `restoreBalance()` used solely by `SaveManager`.

**Abstraction** -- `Job`, `Account`, `Expense`, `Asset`, and `LifeEvent` are
all abstract base classes with pure virtual methods (`calculateMonthlyIncome`,
`applyMonthlyEffect`, `getMonthlyAmount`, `updateValueMonthly`, `apply`).
`GameEngine` only ever holds `unique_ptr<Base>` and never needs to know how
many concrete subtypes exist.

**Inheritance** -- every family above has 3-6 concrete subclasses that
reuse shared base-class data/behavior (e.g. all `Account` subclasses share
`deposit()`/`withdraw()`/`getBalance()` from the base, and only override
what's actually different).

**Polymorphism** -- `GameEngine::doAdvanceMonth()` loops over
`vector<unique_ptr<Account>>`, `vector<unique_ptr<Asset>>`, etc. and calls
the same virtual method on every element (`applyMonthlyEffect()`,
`updateValueMonthly()`) -- the correct interest/depreciation/market-swing
logic runs for each one without a single `if/else` on type. `SaveManager`
additionally demonstrates RTTI-based polymorphism: it uses
`dynamic_cast<ConcreteType*>` to figure out which subclass a base pointer
points to, purely for serialization, while the rest of the program never
needs to ask that question.

## Notes for the report/presentation

- `SaveManager` is intentionally the *only* class allowed to know about
  every concrete subtype -- this keeps serialization logic in one place
  instead of adding a virtual `save()`/`load()` method to every single class.
- Going into debt is modeled as a genuinely negative account balance rather
  than clamping at zero, so the "3 missed payments = bankruptcy" rule has
  something real to check.
- The game is intentionally console/text-based (no graphics) since the
  assignment is about demonstrating OOP design, not building a UI.
