#ifndef GAME_ENGINE_H
#define GAME_ENGINE_H

#include <vector>
#include <memory>
#include "Person.h"
#include "Job.h"
#include "Account.h"
#include "Expense.h"
#include "Asset.h"
#include "Event.h"

// ---------------------------------------------------------------
// GameEngine.h
// The "composition root": owns the Person, the current Job, every
// Account/Expense/Asset, and the pool of possible LifeEvents --
// all through std::unique_ptr<Base>, never through concrete types.
// This is where every other class's polymorphism actually pays
// off: the engine loops over vector<unique_ptr<Account>> and calls
// applyMonthlyEffect() without an if/else on account type, same
// for expenses, assets, and events.
// ---------------------------------------------------------------

class GameEngine {
private:
    Person person;
    std::unique_ptr<Job> currentJob;
    std::vector<std::unique_ptr<Account>> accounts;
    std::vector<std::unique_ptr<Expense>> expenses;
    std::vector<std::unique_ptr<Asset>> assets;
    std::vector<std::unique_ptr<LifeEvent>> eventPool;

    int currentMonth;
    bool gameOver;
    int missedPaymentStreak;

    void buildStartingState();
    void buildEventPool();

    void printDashboard() const;
    void printMainMenu() const;

    void doAdvanceMonth();
    void doDeposit();
    void doWithdraw();
    void doOpenAccount();
    void doBuyAsset();
    void doSellAsset();
    void doSwitchJob();
    void doViewNetWorth();
    void doSaveGame();
    void doLoadGame();

    Account* chooseAccount(const std::string& prompt);
    double totalLiquidCash() const; // sum of all account balances
    double totalAssetValue() const;
    double netWorth() const;
    double totalMonthlyExpenses() const;

    void checkGameOverConditions();

public:
    GameEngine(const std::string& playerName, int startingAge);
    void run(); // main game loop -- shows menu until player quits or game ends
};

#endif // GAME_ENGINE_H
