#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>

// ---------------------------------------------------------------
// Account.h
// Account is abstract. Every account type handles deposits/
// withdrawals the same way (shared, non-virtual logic in the base
// class -- no need to repeat it), but each type applies its own
// monthly behavior (interest, market swings, fees) via the pure
// virtual applyMonthlyEffect(). This separates "what all accounts
// share" from "what makes each account different."
// ---------------------------------------------------------------

class Account {
protected:
    std::string accountName;
    double balance;

public:
    Account(const std::string& accountName, double openingBalance);
    virtual ~Account() = default;

    std::string getName() const;
    double getBalance() const;

    // Shared behavior -- identical for every account type, so it is
    // NOT virtual. Returns false if a withdrawal would overdraw.
    bool deposit(double amount);
    bool withdraw(double amount);

    // Used only by SaveManager when restoring a saved game.
    void restoreBalance(double exactBalance);

    // Pure virtual -- each account type defines its own "what happens
    // at the end of the month" (interest growth, market risk, etc.)
    virtual void applyMonthlyEffect() = 0;
    virtual std::string typeName() const = 0;

    virtual void printSummary() const;
};

class CheckingAccount : public Account {
public:
    CheckingAccount(const std::string& name, double openingBalance);
    void applyMonthlyEffect() override; // no interest, flat fee if balance is low
    std::string typeName() const override;
};

class SavingsAccount : public Account {
private:
    double annualInterestRate; // e.g. 0.04 for 4%
public:
    SavingsAccount(const std::string& name, double openingBalance, double annualInterestRate = 0.04);
    void applyMonthlyEffect() override; // compounds interest monthly
    std::string typeName() const override;
    double getAnnualInterestRate() const;
};

class InvestmentAccount : public Account {
private:
    double riskLevel; // 0..1, higher risk = higher avg return but bigger swings
public:
    InvestmentAccount(const std::string& name, double openingBalance, double riskLevel = 0.5);
    void applyMonthlyEffect() override; // simulates market gain/loss
    std::string typeName() const override;
    double getRiskLevel() const;
};

#endif // ACCOUNT_H
