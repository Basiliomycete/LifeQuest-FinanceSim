#ifndef EXPENSE_H
#define EXPENSE_H

#include <string>

// ---------------------------------------------------------------
// Expense.h
// Abstract base for anything that costs the player money each
// month. getMonthlyAmount() is pure virtual since a fixed bill,
// a variable purchase, and a one-off emergency all compute "how
// much do I cost this month" completely differently.
// ---------------------------------------------------------------

class Expense {
protected:
    std::string label;

public:
    explicit Expense(const std::string& label);
    virtual ~Expense() = default;

    std::string getLabel() const;

    virtual double getMonthlyAmount() const = 0;
    virtual bool isRecurring() const = 0; // does the GameEngine keep this around next month?
    virtual std::string describe() const;
};

class FixedBill : public Expense {
private:
    double amount;
public:
    FixedBill(const std::string& label, double amount);
    double getMonthlyAmount() const override;
    bool isRecurring() const override;
};

class VariableExpense : public Expense {
private:
    double minAmount, maxAmount;
public:
    VariableExpense(const std::string& label, double minAmount, double maxAmount);
    double getMonthlyAmount() const override; // re-rolled each time it's called
    bool isRecurring() const override;
    double getMinAmount() const;
    double getMaxAmount() const;
};

class EmergencyExpense : public Expense {
private:
    double amount;
public:
    EmergencyExpense(const std::string& label, double amount);
    double getMonthlyAmount() const override;
    bool isRecurring() const override; // false -- it happens once, then is removed
};

#endif // EXPENSE_H
