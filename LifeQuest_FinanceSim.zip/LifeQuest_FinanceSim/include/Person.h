#ifndef PERSON_H
#define PERSON_H

#include <string>

// ---------------------------------------------------------------
// Person.h
// Represents the player's Sim. All state is PRIVATE; the outside
// world can only read/modify it through public methods that
// enforce sane ranges (e.g. happiness can never exceed 100).
// This is the clearest demonstration of ENCAPSULATION in the
// project: the invariants live with the data, not with whoever
// happens to be calling the class.
// ---------------------------------------------------------------

class Person {
private:
    std::string name;
    int age;
    int energy;      // 0-100, affects work performance
    int happiness;    // 0-100, affected by spending/events
    int monthsAlive;  // months elapsed in the simulation

    static int clamp(int value, int lo, int hi);

public:
    Person(const std::string& name, int age);

    // --- Getters ---
    std::string getName() const;
    int getAge() const;
    int getEnergy() const;
    int getHappiness() const;
    int getMonthsAlive() const;

    // --- Controlled mutators (never let internal state go out of range) ---
    void changeEnergy(int delta);
    void changeHappiness(int delta);
    void advanceMonth();   // ages up every 12 months, restores some energy

    // Used only by SaveManager when restoring a saved game. Still
    // goes through clamp() so a corrupted save file can't push the
    // Sim's stats out of their valid 0-100 range.
    void restoreState(int energy, int happiness, int monthsAlive);

    // --- Derived/behavioral queries ---
    bool isBurnedOut() const;     // low energy -> job performance penalty
    bool isMiserable() const;     // low happiness -> random bad events more likely
    double productivityMultiplier() const; // used by Job income calculations

    void printStatus() const;
};

#endif // PERSON_H
