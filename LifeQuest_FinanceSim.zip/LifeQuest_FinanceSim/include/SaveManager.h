#ifndef SAVE_MANAGER_H
#define SAVE_MANAGER_H

#include <string>
#include <vector>
#include <memory>
#include "Person.h"
#include "Job.h"
#include "Account.h"
#include "Expense.h"
#include "Asset.h"

// ---------------------------------------------------------------
// SaveManager.h
// Handles writing/reading the whole game state to a plain text
// file. Each polymorphic object is saved with a short type tag
// (e.g. "SAVINGS", "FULLTIME") on its own line; on load, a small
// factory-style function reads the tag and reconstructs the right
// concrete subclass. This keeps (de)serialization logic in ONE
// place instead of scattering "save yourself" virtual methods
// across every class -- a deliberate design tradeoff, not an
// oversight: SaveManager is the one place allowed to know about
// every concrete subtype.
// ---------------------------------------------------------------

class SaveManager {
public:
    static bool save(const std::string& filename,
                      const Person& person,
                      const Job* job,
                      const std::vector<std::unique_ptr<Account>>& accounts,
                      const std::vector<std::unique_ptr<Expense>>& expenses,
                      const std::vector<std::unique_ptr<Asset>>& assets,
                      int currentMonth);

    // On success, fills all output parameters and returns true.
    // On failure (missing/corrupt file), leaves them untouched and returns false.
    static bool load(const std::string& filename,
                      std::string& outName, int& outAge,
                      Person& person,
                      std::unique_ptr<Job>& job,
                      std::vector<std::unique_ptr<Account>>& accounts,
                      std::vector<std::unique_ptr<Expense>>& expenses,
                      std::vector<std::unique_ptr<Asset>>& assets,
                      int& currentMonth);
};

#endif // SAVE_MANAGER_H
