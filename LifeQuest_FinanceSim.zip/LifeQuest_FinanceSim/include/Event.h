#ifndef EVENT_H
#define EVENT_H

#include <string>
#include "Person.h"
#include "Account.h"

// ---------------------------------------------------------------
// Event.h
// LifeEvent is the abstraction for "something random happens this
// month." Each subclass overrides apply() with its own effect on
// the Person and on a chosen Account, and returns a human-readable
// message. The GameEngine just rolls a chance, picks an event
// pointer, and calls apply() -- it has zero knowledge of how many
// event types exist or what each one does internally.
// ---------------------------------------------------------------

class LifeEvent {
protected:
    std::string name;

public:
    explicit LifeEvent(const std::string& name);
    virtual ~LifeEvent() = default;

    std::string getName() const;

    virtual double triggerChancePercent() const = 0; // out of 100, per month
    virtual std::string apply(Person& person, Account& account) const = 0;
};

class BonusEvent : public LifeEvent {
public:
    BonusEvent();
    double triggerChancePercent() const override;
    std::string apply(Person& person, Account& account) const override;
};

class MedicalEmergencyEvent : public LifeEvent {
public:
    MedicalEmergencyEvent();
    double triggerChancePercent() const override;
    std::string apply(Person& person, Account& account) const override;
};

class LotteryWinEvent : public LifeEvent {
public:
    LotteryWinEvent();
    double triggerChancePercent() const override;
    std::string apply(Person& person, Account& account) const override;
};

class TheftEvent : public LifeEvent {
public:
    TheftEvent();
    double triggerChancePercent() const override;
    std::string apply(Person& person, Account& account) const override;
};

class HolidayEvent : public LifeEvent {
public:
    HolidayEvent();
    double triggerChancePercent() const override;
    std::string apply(Person& person, Account& account) const override;
};

class HealthScareEvent : public LifeEvent {
public:
    HealthScareEvent();
    double triggerChancePercent() const override;
    std::string apply(Person& person, Account& account) const override;
};

#endif // EVENT_H
