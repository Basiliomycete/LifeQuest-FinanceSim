#ifndef ASSET_H
#define ASSET_H

#include <string>

// ---------------------------------------------------------------
// Asset.h
// Things the player owns that have a value which changes over
// time. updateValue() is pure virtual: real estate appreciates
// slowly, vehicles depreciate, stocks are volatile. The player's
// net worth is computed by polymorphically summing currentValue()
// over a vector<Asset*> without caring what each one actually is.
// ---------------------------------------------------------------

class Asset {
protected:
    std::string name;
    double purchasePrice;
    double currentValue;

public:
    Asset(const std::string& name, double purchasePrice);
    virtual ~Asset() = default;

    std::string getName() const;
    double getPurchasePrice() const;
    double getCurrentValue() const;

    virtual void updateValueMonthly() = 0;
    virtual std::string typeName() const = 0;
    virtual std::string describe() const;

    // Used only by SaveManager when restoring a saved game.
    void restoreValue(double exactValue);
};

class RealEstate : public Asset {
private:
    double annualAppreciationRate;
public:
    RealEstate(const std::string& name, double purchasePrice, double annualAppreciationRate = 0.03);
    void updateValueMonthly() override;
    std::string typeName() const override;
    double getAppreciationRate() const;
};

class Vehicle : public Asset {
private:
    double annualDepreciationRate;
public:
    Vehicle(const std::string& name, double purchasePrice, double annualDepreciationRate = 0.15);
    void updateValueMonthly() override;
    std::string typeName() const override;
    double getDepreciationRate() const;
};

class StockHolding : public Asset {
private:
    double volatility;
public:
    StockHolding(const std::string& name, double purchasePrice, double volatility = 0.08);
    void updateValueMonthly() override;
    std::string typeName() const override;
    double getVolatility() const;
};

#endif // ASSET_H
