#ifndef JOB_H
#define JOB_H

#include <string>
#include "Person.h"

// ---------------------------------------------------------------
// Job.h
// Job is an ABSTRACT base class (pure virtual calculateMonthlyIncome).
// Every concrete job type computes income differently, but the
// GameEngine only ever talks to a Job* / Job&, never to the
// concrete subtype. That's the abstraction + polymorphism pillar:
// the engine doesn't need an if/else chain on "what kind of job
// is this" -- it just calls income() and the right code runs.
// ---------------------------------------------------------------

class Job {
protected:
    std::string title;
    double baseMonthlyPay;

public:
    Job(const std::string& title, double baseMonthlyPay);
    virtual ~Job() = default;

    std::string getTitle() const;
    double getBasePay() const;

    // Pure virtual -> Job can never be instantiated directly.
    virtual double calculateMonthlyIncome(const Person& person) const = 0;

    // Virtual with default body -> subclasses MAY override, not required.
    virtual int energyCost() const;          // how much energy this job drains
    virtual std::string describe() const;
};

// --- Concrete job types ---

class PartTimeJob : public Job {
public:
    PartTimeJob(const std::string& title, double basePay);
    double calculateMonthlyIncome(const Person& person) const override;
    int energyCost() const override;
};

class FullTimeJob : public Job {
private:
    double annualRaisePercent;
public:
    FullTimeJob(const std::string& title, double basePay, double annualRaisePercent = 3.0);
    double calculateMonthlyIncome(const Person& person) const override;
    int energyCost() const override;
    double getAnnualRaisePercent() const;
};

class Freelancer : public Job {
private:
    double volatility; // 0..1, how much income swings month to month
public:
    Freelancer(const std::string& title, double basePay, double volatility = 0.4);
    double calculateMonthlyIncome(const Person& person) const override;
    int energyCost() const override;
    std::string describe() const override;
    double getVolatility() const;
};

class Entrepreneur : public Job {
private:
    double businessHealth; // 0..2 multiplier, grows or shrinks over time based on luck/energy
public:
    Entrepreneur(const std::string& title, double basePay);
    double calculateMonthlyIncome(const Person& person) const override;
    int energyCost() const override;
    std::string describe() const override;
    void evolveBusiness(); // call once per month: business grows/shrinks
    double getBusinessHealth() const;
    void restoreBusinessHealth(double health); // used only by SaveManager
};

#endif // JOB_H
