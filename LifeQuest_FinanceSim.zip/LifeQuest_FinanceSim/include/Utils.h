#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <random>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <algorithm>

// ---------------------------------------------------------------
// Utils.h
// Small set of free helper functions shared across the project:
// console colors, currency formatting, and a single shared RNG.
// Kept separate from the OOP class hierarchy on purpose -- these
// are stateless utilities, not "things" with identity/behavior,
// so they don't belong inside a class.
// ---------------------------------------------------------------

namespace Color {
    const std::string RESET   = "\033[0m";
    const std::string BOLD    = "\033[1m";
    const std::string RED     = "\033[31m";
    const std::string GREEN   = "\033[32m";
    const std::string YELLOW  = "\033[33m";
    const std::string BLUE    = "\033[34m";
    const std::string MAGENTA = "\033[35m";
    const std::string CYAN    = "\033[36m";
    const std::string GRAY    = "\033[90m";
}

namespace Utils {

    // Shared RNG engine (seeded once at program start)
    inline std::mt19937& rng() {
        static std::mt19937 engine(std::random_device{}());
        return engine;
    }

    inline int randomInt(int lo, int hi) {
        std::uniform_int_distribution<int> dist(lo, hi);
        return dist(rng());
    }

    inline double randomDouble(double lo, double hi) {
        std::uniform_real_distribution<double> dist(lo, hi);
        return dist(rng());
    }

    inline bool chance(double probabilityPercent) {
        return randomDouble(0.0, 100.0) < probabilityPercent;
    }

    // Formats a number as currency, e.g. 1234.5 -> "$1,234.50"
    inline std::string money(double amount) {
        bool negative = amount < 0;
        if (negative) amount = -amount;

        std::ostringstream raw;
        raw << std::fixed << std::setprecision(2) << amount;
        std::string s = raw.str();

        size_t dotPos = s.find('.');
        std::string intPart = s.substr(0, dotPos);
        std::string decPart = s.substr(dotPos);

        std::string withCommas;
        int count = 0;
        for (int i = static_cast<int>(intPart.size()) - 1; i >= 0; --i) {
            withCommas.push_back(intPart[i]);
            count++;
            if (count % 3 == 0 && i != 0) withCommas.push_back(',');
        }
        std::reverse(withCommas.begin(), withCommas.end());

        return std::string(negative ? "-$" : "$") + withCommas + decPart;
    }

    inline void printBar(double fraction, int width = 20) {
        if (fraction < 0) fraction = 0;
        if (fraction > 1) fraction = 1;
        int filled = static_cast<int>(fraction * width);
        std::cout << "[";
        for (int i = 0; i < width; ++i) std::cout << (i < filled ? "#" : "-");
        std::cout << "]";
    }
}

#endif // UTILS_H
